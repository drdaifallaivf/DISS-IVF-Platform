"""Stdlib-only tests for the DISS Engine A core (app/diss/*). No FastAPI, no
DB — these test the clinical logic in isolation, the same discipline used
to validate the engine before it is ever wired behind an API.

Run: python -m pytest tests/test_diss_engine.py -q
(or: python -m unittest tests.test_diss_engine -v, no pytest required)
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.diss import engine, policy, registry, scoring  # noqa: E402


class TestRegistry(unittest.TestCase):
    def test_loads_and_validates(self):
        reg = registry.load_registry()
        self.assertGreater(len(reg["vars"]), 0)

    def test_public_variable_strips_internals(self):
        v = next(x for x in registry.variables() if x.get("sc"))
        pub = registry.public_variable(v)
        for field in ("sc", "weight", "ig", "tier", "flagval", "flagtext"):
            self.assertNotIn(field, pub, f"public_variable leaked {field!r}")
        self.assertIn("rid", pub)
        self.assertIn("name", pub)

    def test_registry_summary_has_no_variable_list(self):
        summary = registry.registry_summary()
        self.assertNotIn("vars", summary)
        self.assertEqual(summary["variable_count"], len(registry.variables()))


class TestScoring(unittest.TestCase):
    def test_win_inside_band_is_100(self):
        sc = {"t": "win", "lo": 18.5, "hi": 24.9, "loHard": 13, "hiHard": 40}
        self.assertEqual(scoring.score_of(sc, 22), 100.0)

    def test_win_outside_hard_limit_floors_at_zero(self):
        sc = {"t": "win", "lo": 18.5, "hi": 24.9, "loHard": 13, "hiHard": 40}
        self.assertEqual(scoring.score_of(sc, 40), 0.0)

    def test_bin_yes_no(self):
        sc = {"t": "bin", "yes": 20, "no": 100}
        self.assertEqual(scoring.score_of(sc, "Yes"), 20)
        self.assertEqual(scoring.score_of(sc, "No"), 100)
        self.assertIsNone(scoring.score_of(sc, "Unsure"))

    def test_missing_value_is_none(self):
        sc = {"t": "high", "T": 10, "L": 1}
        self.assertIsNone(scoring.score_of(sc, None))
        self.assertIsNone(scoring.score_of(sc, ""))


class TestEngineInvariants(unittest.TestCase):
    """Mirrors the 7 invariants enforced in the earlier v0.2 engine build."""

    def _first_absolute_flag_rid(self):
        v = next(v for v in registry.variables() if v.get("tier") == "A")
        return v

    def test_I1_absolute_flag_is_not_ready_regardless_of_score(self):
        v = self._first_absolute_flag_rid()
        fv = v.get("flagval") or {"vals": ["Yes"]}
        # Build a trigger value for whichever shape this flag uses.
        if fv.get("vals"):
            trigger = fv["vals"][0]
        elif fv.get("numge") is not None:
            trigger = fv["numge"]
        elif fv.get("numlt") is not None:
            trigger = fv["numlt"] - 1
        else:
            self.skipTest("flag has no recognizable trigger shape")
        result = engine.assess({v["rid"]: trigger})
        self.assertTrue(result["flags"]["A"], "absolute flag did not fire")
        self.assertEqual(result["readiness"]["level"], "Not Ready — STOP")

    def test_I2_overall_is_mean_of_assessed_pillars_only(self):
        # Score only pillar I variables; pillars II-V must stay unassessed
        # (None), never averaged in as if they were zero.
        values = {}
        for v in registry.variables():
            if v["pillar"] == "I" and v.get("sc") and v["sc"].get("t") == "bin":
                values[v["rid"]] = "No"
                break
        result = engine.assess(values)
        for p in ("II", "III", "IV", "V"):
            self.assertIsNone(result["per_pillar"][p], f"pillar {p} should be unassessed")

    def test_I3_weakest_link_floor_caps_a_single_bad_score(self):
        # Two synthetic variables in the same pillar, weight 1 each: one
        # perfect (100), one catastrophic (0). Naive mean = 50, but the
        # weakest-link floor must cap it at min(0)+8 = 8 because 0 < 35.
        import json
        import tempfile

        synth = {
            "registry_version": "test",
            "pillar_order": ["I", "II", "III", "IV", "V"],
            "pillar_names": policy.PILLAR_NAMES,
            "vars": [
                {"rid": "TEST-V001", "name": "Perfect", "pillar": "I", "input": "sel",
                 "sc": {"t": "bin", "yes": 100, "no": 0}, "weight": 1, "mand": False},
                {"rid": "TEST-V002", "name": "Catastrophic", "pillar": "I", "input": "sel",
                 "sc": {"t": "bin", "yes": 0, "no": 100}, "weight": 1, "mand": False},
            ],
        }
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump(synth, f)
            path = f.name
        registry.load_registry.cache_clear()
        try:
            result = engine.assess({"TEST-V001": "Yes", "TEST-V002": "Yes"}, registry_path=path)
        finally:
            registry.load_registry.cache_clear()
        pillar_score = result["per_pillar"]["I"]["score"]
        self.assertLessEqual(pillar_score, 8 + 1, "weakest-link floor was not applied")

    def test_I4_not_assessed_is_its_own_status_never_pass(self):
        result = engine.assess({})
        for p in policy.PILLAR_ORDER:
            self.assertEqual(result["pillar_status"][p], "NOT_ASSESSED")
        self.assertEqual(result["readiness"]["level"], "Unassessed")

    def test_I6_projected_is_always_labelled_estimated(self):
        result = engine.assess({})
        # unassessed -> no projection at all
        self.assertIsNone(result["projected"])

    def test_I7_projection_refused_when_flag_A_active(self):
        v = self._first_absolute_flag_rid()
        fv = v.get("flagval") or {"vals": ["Yes"]}
        trigger = fv["vals"][0] if fv.get("vals") else (fv.get("numge") or (fv.get("numlt") - 1))
        result = engine.assess({v["rid"]: trigger})
        self.assertIsNone(result["projected"], "projection must be refused when Not Ready — STOP")


class TestReportRedaction(unittest.TestCase):
    def test_clinician_report_never_exposes_weights_or_thresholds(self):
        from app.diss import report

        result = engine.assess({})
        rep = report.build(result, tier="both")
        blob = str(rep)
        # These are internal-only tokens that must never leak into a report.
        for forbidden in ('"weight"', '"sc"', '"flagval"', '"ig"'):
            self.assertNotIn(forbidden, blob)


if __name__ == "__main__":
    unittest.main()
