import os
os.environ["DATABASE_URL"] = "sqlite:///./test_diss.db"
from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

def test_health():
    r=client.get('/health'); assert r.status_code==200; assert r.json()['clinical_autonomy'] is False

def test_patient_create():
    r=client.post('/api/patients', json={"mrn":"TEST-001","full_name":"Test Patient","center":"Test Center"})
    assert r.status_code in (200,409)

def test_diss_registry_summary_has_no_variable_list():
    r = client.get('/api/diss/registry')
    assert r.status_code == 200
    body = r.json()
    assert 'vars' not in body
    assert body['variable_count'] > 0

def test_diss_variables_never_leak_weight_or_scoring_config():
    r = client.get('/api/diss/variables')
    assert r.status_code == 200
    body = r.json()
    assert len(body) > 0
    for v in body:
        assert 'weight' not in v
        assert 'sc' not in v
        assert 'tier' not in v
        assert 'flagval' not in v

def test_diss_assess_absolute_flag_forces_not_ready():
    r = client.post('/api/patients', json={"mrn":"TEST-DISS-001","full_name":"DISS Test Patient"})
    pid = r.json()['id'] if r.status_code == 200 else client.get('/api/patients').json()[0]['id']
    # OHSS Severity = Critical is an unconditional Absolute-tier trigger.
    client.post(f'/api/patients/{pid}/diss/inputs', json={"inputs":[{"rid":"DISS-P3-D03-C04-V059","value":"Critical"}]})
    res = client.post(f'/api/patients/{pid}/diss/assess?tier=clinician').json()
    assert res['report']['readiness']['level'] == 'Not Ready — STOP'

def test_diss_assessment_replay_matches_original():
    r = client.post('/api/patients', json={"mrn":"TEST-DISS-002","full_name":"DISS Replay Patient"})
    pid = r.json()['id'] if r.status_code == 200 else client.get('/api/patients').json()[0]['id']
    client.post(f'/api/patients/{pid}/diss/inputs', json={"inputs":[{"rid":"DISS-P1-D01-C03-V025","value":"33"}]})
    first = client.post(f'/api/patients/{pid}/diss/assess?tier=patient').json()
    replay = client.get(f"/api/diss/assessments/{first['assessment_id']}").json()
    assert replay['report'] == first['report']
