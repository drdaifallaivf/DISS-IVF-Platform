# DISS™ Reproductive Medicine Intelligence, Operating, Financial & Commerce Ecosystem

**v0.2.0** — this build replaces the v0.1 placeholder clinical engine with a
real, tested port of **DISS Engine A (Readiness)**: the same locked
scoring functions, weakest-link floor, and three-tier criticality gate
(Absolute / Conditional / Hold) used by the DISS demo reports, wired to a
692-variable clinical registry.

## What changed from v0.1

- `app/diss/` — a new, stdlib-only package (no fastapi/sqlalchemy import)
  holding the clinical core: `policy.py` (every governed constant on one
  page), `scoring.py` (the six locked scoring functions, ported 1:1 from
  the reference calculator), `registry.py` (loads + validates the bundled
  692-variable registry, and draws the line between internal scoring
  config and what's safe to expose publicly), `engine.py` (pillar
  aggregation, the criticality gate, the overall verdict), `report.py`
  (patient-tier and clinician-tier report assembly).
- `app/data/registry.json` — the real DISS Clinical Knowledge Registry
  (692 variables across the Five Clinical Pillars™), exported from the
  reference calculator's dataset. `DISS_REGISTRY_PATH` overrides it with a
  newer export without a code change.
- `app/clinical_engine.py` rewritten as the DB↔core boundary: patient
  inputs are captured per-variable (by Registry ID) in `DISSInput`, an
  assessment run is computed and stored **immutably** in `DISSAssessment`
  — replaying an old assessment never recomputes against a since-changed
  registry or since-edited inputs.
- New API: `GET /api/diss/registry` (aggregate counts only), `GET
  /api/diss/variables` (public-safe field metadata for a data-entry form —
  **never** weight, scoring parameters, criticality tier, or the exact
  red-flag trigger value), `POST /api/patients/{id}/diss/inputs`, `POST
  /api/patients/{id}/diss/assess?tier=patient|clinician|both`, `GET
  /api/patients/{id}/diss/assessments`, `GET
  /api/diss/assessments/{assessment_id}` (replay).
- The command-center UI (`app/static/index.html`) gained a **DISS
  Assessment** tab: pick/create a patient, enter a curated slice of key
  variables across all Five Pillars, run the engine, see pillar status
  chips, the readiness verdict, data confidence, and a Finding →
  Interpretation → Recommendation table for every active flag.
- `tests/test_diss_engine.py` — 14 stdlib-only tests covering scoring
  correctness, registry validation/redaction, and the same engine
  invariants verified in earlier DISS engine work (I-1 absolute flag stops
  readiness regardless of score, I-2 overall is the mean of ASSESSED
  pillars only, I-3 the weakest-link floor caps one catastrophic finding,
  I-4 Not Assessed is its own status, I-6/I-7 projection is refused when
  Not Ready). Run with `python -m unittest tests.test_diss_engine -v` —
  no FastAPI/DB dependency required.

## Confidentiality note (kept from the product's standing discipline)

`app/diss/registry.py`'s `public_variable()` / `public_variables()` /
`registry_summary()` are the ONLY functions allowed to back a public or
unauthenticated response, and they deliberately strip weight, scoring
config, information-gain, criticality tier and the exact flag-trigger
condition. `tests/test_diss_engine.py::TestReportRedaction` and
`tests/test_app.py::test_diss_variables_never_leak_weight_or_scoring_config`
assert this. If you add a new endpoint that touches `registry.variables()`
directly, run those tests before shipping it — that raw list carries the
full clinical IP.

## Important clinical boundary (unchanged from v0.1)

This is a decision-support demo, not an autonomous clinical system. Every
report carries "Clinician-in-the-loop decision support · provisional
weights · not for autonomous clinical use." Weights are provisional
(GRADE-derived, pending prospective calibration); the projected/estimated
score is an explicitly-labelled heuristic, never a validated prediction.

## What is included

- Patient Digital Twin foundation, DISS Readiness Engine (Engine A) wired
  end-to-end, IVF cycle records, embryology specimen records, physician
  recommendation approval/modify/reject workflow (auto-populated from
  active DISS flags), patient financial ledger, department/cost-center
  model, inventory + shortage detection, suppliers, marketplace products,
  commercial/clinical separation guardrail, executive dashboard API, a
  command-center web UI with a DISS assessment workflow, SQLite default
  (PostgreSQL-ready), Docker support, tests.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python -m app.seed
uvicorn app.main:app --reload
```

Open: `http://127.0.0.1:8000` — the DISS Assessment tab has the demo
patient (`DISS-0001`) pre-seeded with a few pillar-I/II/III values so a
first run shows something immediately.

API docs: `http://127.0.0.1:8000/docs`

Run tests:

```bash
python -m unittest tests.test_diss_engine -v   # stdlib engine core, no deps beyond stdlib
pytest -q                                       # full API suite (needs deps installed)
```

## Deploying on Render (same pattern as the DISS App)

1. Zip this whole directory (or use the pre-built
   `DISS_Platform_Render_Release_v0.2.0.zip` release) and upload it to the
   repo root of the GitHub repo Render will deploy from, via GitHub's web
   "Add file → Upload files" — no local git needed.
2. Render service settings:
   - **Build command**: `rm -rf _deploy && mkdir _deploy && unzip -q DISS_Platform_Render_Release_v0.2.0.zip -d _deploy && pip install -r _deploy/requirements.txt && cd _deploy && python -m app.seed`
   - **Start command**: `cd _deploy && uvicorn app.main:app --host 0.0.0.0 --port $PORT`
   - **Health check path**: `/health`
3. SQLite is ephemeral on Render's default filesystem unless a persistent
   disk is attached and `DATABASE_URL` points at it — fine for a live
   demo, not for real patient data.

## Production hardening required before real patient use

This starter is **not production-ready for PHI/clinical deployment**.
Before any real-world use add at minimum: authentication, MFA, RBAC/ABAC,
SSO; tenant isolation and center-level data boundaries; encryption and key
management; immutable audit logging and provenance; consent and privacy
workflows; FHIR/HL7/DICOM integration layer; secure file/object storage;
backup/disaster recovery; full accounting ledger and reconciliation;
procurement approvals and purchase-order lines; inventory movements and
lot-level traceability; embryology witnessing/identity controls;
device/LIS/PACS interfaces; a prospective-cohort weight calibration before
any weight is called validated; clinical safety case and human-factors
testing; regulatory/privacy/legal assessment for each deployment
jurisdiction; competition-law review for aggregated marketplace demand
analytics; formal separation of clinical intelligence from paid commercial
placement.

## Suggested next build milestones

1. **v0.3 IVF & Embryology:** cycle timeline, specimen lineage, cryostorage
   and images.
2. **v0.4 Enterprise:** RBAC, multi-center command center, finance/cost
   centers, inventory movements.
3. **v0.5 Commerce:** RFQ, supplier quotations, purchasing approvals,
   marketplace transactions.
4. **v0.6 Supply Intelligence:** demand forecasting using aggregated,
   privacy-preserving operational data.
