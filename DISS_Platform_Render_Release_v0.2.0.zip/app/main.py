import json
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import select, func
from .database import Base, engine, get_db
from . import models, schemas
from . import clinical_engine

Base.metadata.create_all(bind=engine)
app = FastAPI(title="DISS Reproductive Medicine Intelligence & Operating Ecosystem", version="0.2.0")
STATIC_DIR = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/", include_in_schema=False)
def home():
    return FileResponse(STATIC_DIR / "index.html")

@app.get("/health")
def health():
    return {
        "status": "ok",
        "clinical_autonomy": False,
        "diss_engine": clinical_engine.registry_summary()["registry_version"],
    }

@app.post("/api/patients", response_model=schemas.PatientOut)
def create_patient(payload: schemas.PatientCreate, db: Session = Depends(get_db)):
    if db.scalar(select(models.Patient).where(models.Patient.mrn == payload.mrn)):
        raise HTTPException(409, "MRN already exists")
    p = models.Patient(**payload.model_dump()); db.add(p); db.commit(); db.refresh(p); return p

@app.get("/api/patients", response_model=list[schemas.PatientOut])
def list_patients(db: Session = Depends(get_db)):
    return list(db.scalars(select(models.Patient).order_by(models.Patient.created_at.desc())).all())

@app.get("/api/patients/{patient_id}")
def patient_detail(patient_id:int, db:Session=Depends(get_db)):
    p = db.get(models.Patient, patient_id)
    if not p: raise HTTPException(404, "Patient not found")
    data = db.scalars(select(models.ClinicalDatum).where(models.ClinicalDatum.patient_id==patient_id)).all()
    cycles = db.scalars(select(models.IVFcycle).where(models.IVFcycle.patient_id==patient_id)).all()
    recs = db.scalars(select(models.ClinicalRecommendation).where(models.ClinicalRecommendation.patient_id==patient_id)).all()
    ledger = db.scalars(select(models.PatientLedger).where(models.PatientLedger.patient_id==patient_id)).all()
    balance = sum(float(x.amount) if x.entry_type=="charge" else -float(x.amount) for x in ledger if x.entry_type in {"charge","payment"})
    return {"patient": schemas.PatientOut.model_validate(p), "clinical_data":[row_to_dict(x) for x in data], "cycles":[row_to_dict(x) for x in cycles], "recommendations":[row_to_dict(x) for x in recs], "ledger":[row_to_dict(x) for x in ledger], "balance":balance}

@app.post("/api/patients/{patient_id}/clinical-data")
def add_clinical_data(patient_id:int, payload:schemas.ClinicalDatumCreate, db:Session=Depends(get_db)):
    if not db.get(models.Patient, patient_id): raise HTTPException(404, "Patient not found")
    x = models.ClinicalDatum(patient_id=patient_id, **payload.model_dump()); db.add(x); db.commit(); db.refresh(x); return row_to_dict(x)

@app.post("/api/patients/{patient_id}/cycles")
def create_cycle(patient_id:int, payload:schemas.CycleCreate, db:Session=Depends(get_db)):
    if not db.get(models.Patient, patient_id): raise HTTPException(404, "Patient not found")
    x = models.IVFcycle(patient_id=patient_id, **payload.model_dump()); db.add(x); db.commit(); db.refresh(x); return row_to_dict(x)

@app.get("/api/diss/registry")
def diss_registry_summary():
    """Aggregate counts only (pillar names, variable counts). Never returns
    the variable list itself — use /api/diss/variables for that."""
    return clinical_engine.registry_summary()

@app.get("/api/diss/variables")
def diss_variables():
    """Public-safe variable metadata for building a data-entry form: rid,
    name, pillar, unit, input type, options. Never includes weight, scoring
    parameters, criticality tier or the exact red-flag trigger value."""
    return clinical_engine.public_variables()

@app.post("/api/patients/{patient_id}/diss/inputs")
def diss_add_inputs(patient_id:int, payload:schemas.DISSInputBatch, db:Session=Depends(get_db)):
    if not db.get(models.Patient, patient_id): raise HTTPException(404, "Patient not found")
    rows = clinical_engine.upsert_inputs(db, patient_id, [i.model_dump() for i in payload.inputs])
    return [row_to_dict(r) for r in rows]

@app.get("/api/patients/{patient_id}/diss/inputs")
def diss_list_inputs(patient_id:int, db:Session=Depends(get_db)):
    if not db.get(models.Patient, patient_id): raise HTTPException(404, "Patient not found")
    return clinical_engine.current_values(db, patient_id)

@app.post("/api/patients/{patient_id}/diss/assess")
def diss_assess(patient_id:int, tier:str="both", db:Session=Depends(get_db)):
    if not db.get(models.Patient, patient_id): raise HTTPException(404, "Patient not found")
    if tier not in ("patient", "clinician", "both"): raise HTTPException(422, "tier must be patient|clinician|both")
    row = clinical_engine.run_assessment(db, patient_id, tier=tier)
    return {"assessment_id": row.id, "created_at": row.created_at, "report": json.loads(row.report_json)}

@app.get("/api/patients/{patient_id}/diss/assessments")
def diss_assessment_history(patient_id:int, db:Session=Depends(get_db)):
    if not db.get(models.Patient, patient_id): raise HTTPException(404, "Patient not found")
    rows = clinical_engine.list_assessments(db, patient_id)
    return [{"id": r.id, "created_at": r.created_at, "registry_version": r.registry_version, "tier": r.tier} for r in rows]

@app.get("/api/diss/assessments/{assessment_id}")
def diss_assessment_replay(assessment_id:int, db:Session=Depends(get_db)):
    """Replays the STORED result — never recomputes. What a clinician was
    shown is a matter of record, even if inputs are edited afterwards."""
    row = clinical_engine.replay_assessment(db, assessment_id)
    if not row: raise HTTPException(404, "Assessment not found")
    return {"assessment_id": row.id, "created_at": row.created_at, "registry_version": row.registry_version, "report": json.loads(row.report_json)}

@app.patch("/api/recommendations/{rec_id}")
def decide_recommendation(rec_id:int, payload:schemas.RecommendationDecision, db:Session=Depends(get_db)):
    x=db.get(models.ClinicalRecommendation, rec_id)
    if not x: raise HTTPException(404, "Recommendation not found")
    x.status=payload.status; x.physician_comment=payload.physician_comment; db.commit(); db.refresh(x); return row_to_dict(x)

@app.post("/api/patients/{patient_id}/ledger")
def add_ledger(patient_id:int, payload:schemas.LedgerCreate, db:Session=Depends(get_db)):
    if not db.get(models.Patient, patient_id): raise HTTPException(404, "Patient not found")
    x=models.PatientLedger(patient_id=patient_id, **payload.model_dump()); db.add(x); db.commit(); db.refresh(x); return row_to_dict(x)

@app.post("/api/suppliers")
def create_supplier(payload:schemas.SupplierCreate, db:Session=Depends(get_db)):
    x=models.Supplier(**payload.model_dump()); db.add(x); db.commit(); db.refresh(x); return row_to_dict(x)

@app.get("/api/suppliers")
def list_suppliers(db:Session=Depends(get_db)):
    return [row_to_dict(x) for x in db.scalars(select(models.Supplier)).all()]

@app.post("/api/inventory")
def create_inventory(payload:schemas.InventoryCreate, db:Session=Depends(get_db)):
    x=models.InventoryItem(**payload.model_dump()); db.add(x); db.commit(); db.refresh(x); return row_to_dict(x)

@app.get("/api/inventory")
def list_inventory(db:Session=Depends(get_db)):
    return [row_to_dict(x) for x in db.scalars(select(models.InventoryItem)).all()]

@app.get("/api/inventory/shortages")
def shortages(db:Session=Depends(get_db)):
    rows=db.scalars(select(models.InventoryItem).where(models.InventoryItem.qty_on_hand <= models.InventoryItem.reorder_level)).all()
    return [row_to_dict(x) for x in rows]

@app.post("/api/marketplace/products")
def add_marketplace(payload:schemas.MarketplaceCreate, db:Session=Depends(get_db)):
    x=models.MarketplaceProduct(**payload.model_dump()); db.add(x); db.commit(); db.refresh(x); return row_to_dict(x)

@app.get("/api/marketplace/products")
def marketplace(db:Session=Depends(get_db)):
    return [row_to_dict(x) for x in db.scalars(select(models.MarketplaceProduct).where(models.MarketplaceProduct.active==True)).all()]

@app.get("/api/dashboard")
def dashboard(db:Session=Depends(get_db)):
    patients = db.scalar(select(func.count(models.Patient.id))) or 0
    cycles = db.scalar(select(func.count(models.IVFcycle.id))) or 0
    shortages_n = db.scalar(select(func.count(models.InventoryItem.id)).where(models.InventoryItem.qty_on_hand <= models.InventoryItem.reorder_level)) or 0
    marketplace_n = db.scalar(select(func.count(models.MarketplaceProduct.id)).where(models.MarketplaceProduct.active==True)) or 0
    receivables = 0.0
    for x in db.scalars(select(models.PatientLedger)).all():
        if x.entry_type == "charge": receivables += float(x.amount)
        elif x.entry_type == "payment": receivables -= float(x.amount)
    return {"patients":patients, "cycles":cycles, "shortages":shortages_n, "marketplace_products":marketplace_n, "receivables":round(receivables,2)}

def row_to_dict(obj):
    return {c.name: getattr(obj, c.name) for c in obj.__table__.columns}
