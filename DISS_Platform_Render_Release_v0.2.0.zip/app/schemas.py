from datetime import date, datetime
from decimal import Decimal
from pydantic import BaseModel, ConfigDict

class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)

class PatientCreate(BaseModel):
    mrn: str
    full_name: str
    dob: date | None = None
    sex: str | None = None
    phone: str | None = None
    email: str | None = None
    center: str | None = None

class PatientOut(ORMModel):
    id: int; mrn: str; full_name: str; dob: date | None; sex: str | None; center: str | None; status: str

class ClinicalDatumCreate(BaseModel):
    category: str
    name: str
    value_text: str | None = None
    value_num: float | None = None
    unit: str | None = None
    source: str | None = None
    verified: bool = False
    observed_at: datetime | None = None

class CycleCreate(BaseModel):
    cycle_code: str
    phase: str = "assessment"
    protocol_name: str | None = None

class RecommendationDecision(BaseModel):
    status: str
    physician_comment: str | None = None

class LedgerCreate(BaseModel):
    entry_type: str
    category: str
    description: str
    amount: Decimal
    currency: str = "SAR"
    cycle_id: int | None = None

class InventoryCreate(BaseModel):
    sku: str; name: str; category: str; center: str; department: str
    qty_on_hand: float = 0; reorder_level: float = 0; unit_cost: Decimal = Decimal("0")
    supplier_id: int | None = None; lot_number: str | None = None; expiry_date: date | None = None

class SupplierCreate(BaseModel):
    name: str
    contact_email: str | None = None
    phone: str | None = None

class DISSInputCreate(BaseModel):
    rid: str
    value: str
    source: str | None = None
    verified: bool = False


class DISSInputBatch(BaseModel):
    inputs: list[DISSInputCreate]


class MarketplaceCreate(BaseModel):
    supplier_id: int
    sku: str
    name: str
    category: str
    description: str | None = None
    price: Decimal | None = None
    currency: str = "SAR"
    sponsored: bool = False
