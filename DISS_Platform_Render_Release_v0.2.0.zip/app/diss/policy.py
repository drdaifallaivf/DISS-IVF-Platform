"""Every governed clinical-logic constant, on one page.

These values are the locked policy from the DISS Scientific Lock (Sprint 1)
and Clinical Logic Rulebook (Sprint 2). Do not duplicate a magic number
anywhere else in this package — import it from here so a policy change is a
one-line diff with an obvious blast radius.
"""

PILLAR_ORDER = ["I", "II", "III", "IV", "V"]

PILLAR_NAMES = {
    "I": "Medical & Endocrine",
    "II": "Anatomical & Surgical",
    "III": "Embryology & Gamete Competence",
    "IV": "Reproductive Genetics & Precision Medicine",
    "V": "Patient Partnership & Psychosocial Readiness",
}

# Band thresholds (score >= threshold -> band), checked in order.
BANDS = [
    ("PASS", 80),
    ("HOLD", 60),
    ("REVIEW", 40),
    ("STOP", 0),
]

# Weakest-link floor: if a pillar's minimum-scoring assessed variable falls
# below this severity threshold, the pillar score is capped at min + CEIL,
# regardless of the weighted mean. Prevents one catastrophic finding from
# being averaged away by many mild ones.
WEAKEST_LINK_SEVERITY = 35
WEAKEST_LINK_CEILING_ADD = 8

# Criticality tiers, in gating precedence order. A = Absolute (hard stop
# regardless of score, anywhere), C = Conditional (blocks readiness until its
# named condition is met), H = Hold-for-optimization (soft, can still show
# PASS-level score but is downgraded one notch).
TIERS = ["A", "C", "H"]

# Data-confidence thresholds: % of MANDATORY-CORE variables assessed.
CONFIDENCE_HIGH_PCT = 80
CONFIDENCE_MODERATE_PCT = 50

# Projected-score heuristic target (Sprint 3). This is explicitly an
# UNVALIDATED heuristic — never present it as a clinical prediction.
PROJECTED_SCORE_TARGET = 85
PROJECTED_SCORE_LABEL = "Estimated — heuristic, not validated"


def band(score):
    """Map a 0-100 score to (band_name,) using the locked thresholds."""
    for name, minimum in BANDS:
        if score >= minimum:
            return name
    return "STOP"
