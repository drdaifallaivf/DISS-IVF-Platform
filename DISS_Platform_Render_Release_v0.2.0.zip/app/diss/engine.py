"""Engine A — Readiness. Ported 1:1 from the live calculator's `compute`,
`flagActive`, `pillarStatus` and `readiness` functions.

Public entry point: `assess(values, registry_path=None)`.

`values` is a plain dict of {rid: value}. A variable counts as "provided"
iff its rid is a key in `values` with a non-None, non-empty value — exactly
mirroring the original's `isProvided`. Everything else (scoring, the
weakest-link floor, the three-tier criticality gate, the overall verdict)
is computed the same way the calculator computes it, so a case run through
this API and the same case run through the calculator agree.
"""
from __future__ import annotations

from . import policy, registry, scoring


def is_provided(v: dict, values: dict) -> bool:
    val = values.get(v["rid"])
    return val is not None and val != ""


def cur_val(v: dict, values: dict):
    return values.get(v["rid"])


def flag_active(v: dict, values: dict) -> bool:
    tier = v.get("tier")
    if not tier:
        return False
    val = values.get(v["rid"])
    if val is None or val == "":
        return False
    fv = v.get("flagval") or {"vals": ["Yes"]}
    vals = fv.get("vals")
    if vals and val in vals:
        return True
    numlt = fv.get("numlt")
    if numlt is not None:
        try:
            if float(val) < numlt:
                return True
        except (TypeError, ValueError):
            pass
    numge = fv.get("numge")
    if numge is not None:
        try:
            if float(val) >= numge:
                return True
        except (TypeError, ValueError):
            pass
    return False


def compute(values: dict, registry_path: str | None = None) -> dict:
    """Returns {"perP": {pillar: {"score","n","min"} | None}, "flags": {"A","C","H": [var,...]}}."""
    per = {p: {"wsum": 0.0, "sum": 0.0, "min": 101.0, "n": 0} for p in policy.PILLAR_ORDER}
    flags = {"A": [], "C": [], "H": []}

    for v in registry.variables(registry_path):
        if flag_active(v, values):
            flags[v["tier"]].append(v)
        if not is_provided(v, values) or not v.get("sc"):
            continue
        s = scoring.score_of(v["sc"], cur_val(v, values))
        if s is None:
            continue
        w = v.get("weight") or 1
        P = per[v["pillar"]]
        P["wsum"] += s * w
        P["sum"] += w
        P["n"] += 1
        if s < P["min"]:
            P["min"] = s

    per_p = {}
    for p in policy.PILLAR_ORDER:
        P = per[p]
        if P["n"] == 0:
            per_p[p] = None
            continue
        sc = P["wsum"] / P["sum"]
        if P["min"] < policy.WEAKEST_LINK_SEVERITY:
            sc = min(sc, P["min"] + policy.WEAKEST_LINK_CEILING_ADD)
        per_p[p] = {"score": round(sc), "n": P["n"], "min": round(P["min"])}

    return {"perP": per_p, "flags": flags}


def pillar_status(pil: str, per_p: dict, flags: dict) -> str:
    if any(f["pillar"] == pil for f in flags["A"]):
        return "STOP"
    P = per_p.get(pil)
    if not P:
        return "NOT_ASSESSED"
    n = policy.band(P["score"])
    if any(f["pillar"] == pil for f in flags["C"]) and n in ("PASS", "HOLD"):
        return "REVIEW"
    if any(f["pillar"] == pil for f in flags["H"]) and n == "PASS":
        return "HOLD"
    return n


def readiness(per_p: dict, flags: dict) -> dict:
    if flags["A"]:
        return {
            "level": "Not Ready — STOP",
            "sub": "An absolute red flag is active. Resolve it before any treatment.",
        }
    engaged = [p for p in policy.PILLAR_ORDER if per_p.get(p)]
    if not engaged:
        return {"level": "Unassessed", "sub": "Enter findings to begin."}
    statuses = [pillar_status(p, per_p, flags) for p in engaged]
    if flags["C"]:
        return {
            "level": "Partially Ready — conditional",
            "sub": "A conditional red flag applies: proceed only once its stated condition is met.",
        }
    if "STOP" in statuses:
        return {"level": "Not Ready", "sub": "A pillar is at STOP. Resolve before proceeding."}
    if "REVIEW" in statuses:
        return {"level": "Partially Ready", "sub": "Investigate the REVIEW-level pillar(s), then re-score."}
    if "HOLD" in statuses:
        return {"level": "Nearly Ready — optimise", "sub": "Optimise the HOLD-level factors, then re-score."}
    return {"level": "Ready", "sub": "Readiness met across the assessed pillars. Continue maintenance measures."}


def overall_score(per_p: dict):
    scores = [per_p[p]["score"] for p in policy.PILLAR_ORDER if per_p.get(p)]
    if not scores:
        return None
    return round(sum(scores) / len(scores))


def data_confidence(values: dict, registry_path: str | None = None) -> dict:
    vs = registry.variables(registry_path)
    mandatory = [v for v in vs if v.get("mand")]
    provided = [v for v in mandatory if is_provided(v, values)]
    pct = round(100 * len(provided) / len(mandatory)) if mandatory else 0
    if pct >= policy.CONFIDENCE_HIGH_PCT:
        level = "High"
    elif pct >= policy.CONFIDENCE_MODERATE_PCT:
        level = "Moderate"
    else:
        level = "Low"
    return {"pct": pct, "level": level, "provided": len(provided), "total": len(mandatory)}


def projected_score(per_p: dict, flags: dict) -> dict | None:
    """Sprint-3 heuristic: NEVER present as validated. Raises each assessed
    pillar toward the target band; never clears a red flag."""
    if flags["A"]:
        return None
    assessed = [p for p in policy.PILLAR_ORDER if per_p.get(p)]
    if not assessed:
        return None
    cur = overall_score(per_p)
    target = policy.PROJECTED_SCORE_TARGET
    proj = round(
        sum(target if per_p[p]["score"] < target else per_p[p]["score"] for p in assessed) / len(assessed)
    )
    proj = min(100, max(proj, cur))
    return {"current": cur, "projected": proj, "gain": proj - cur, "label": policy.PROJECTED_SCORE_LABEL}


def assess(values: dict, registry_path: str | None = None) -> dict:
    """Full Engine A pass over one set of {rid: value} inputs."""
    result = compute(values, registry_path)
    per_p, flags = result["perP"], result["flags"]
    pillar_statuses = {p: pillar_status(p, per_p, flags) for p in policy.PILLAR_ORDER}
    return {
        "registry_version": registry.registry_version(registry_path),
        "per_pillar": per_p,
        "pillar_status": pillar_statuses,
        "flags": {
            tier: [
                {"rid": f["rid"], "name": f["name"], "pillar": f["pillar"], "flagtext": f.get("flagtext")}
                for f in flist
            ]
            for tier, flist in flags.items()
        },
        "overall_score": overall_score(per_p),
        "readiness": readiness(per_p, flags),
        "data_confidence": data_confidence(values, registry_path),
        "projected": projected_score(per_p, flags),
    }
