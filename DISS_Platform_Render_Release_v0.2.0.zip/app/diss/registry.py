"""Loads and validates the bundled DISS Clinical Knowledge Registry.

REGISTRY IS DATA, NOT CODE. The engine only ever runs against a loaded,
validated registry file — never against improvised variables or weights.
`DISS_REGISTRY_PATH` overrides the bundled default so a real, updated
registry export can be swapped in without a code change.

This module also draws the line between what the engine needs internally
(scoring config, weight, criticality tier, exact flag-trigger values — the
proprietary clinical logic) and what an assessment UI or a partner-facing
API response is allowed to see (name, unit, input type, options, whether a
field is mandatory). `public_variable()` is the ONLY function that should
back a public/unauthenticated API response — it strips every field that
would hand over the scoring formulas.
"""
from __future__ import annotations

import json
import os
from functools import lru_cache

_DEFAULT_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "registry.json")

# Fields on a variable record that are internal clinical IP: the scoring
# function and its parameters, the clinical weight, the information-gain
# score, the criticality tier, and the exact numeric/categorical trigger
# that activates a red flag. None of these are ever served publicly.
_INTERNAL_ONLY_FIELDS = {"sc", "weight", "ig", "tier", "flagval", "flagtext", "redflag", "pid"}

REQUIRED_VAR_FIELDS = {"rid", "name", "pillar", "input"}


class RegistryError(Exception):
    pass


def _validate(registry: dict) -> None:
    if "vars" not in registry or not isinstance(registry["vars"], list):
        raise RegistryError("registry missing 'vars' list")
    if not registry["vars"]:
        raise RegistryError("registry has zero variables")
    seen = set()
    for v in registry["vars"]:
        missing = REQUIRED_VAR_FIELDS - v.keys()
        if missing:
            raise RegistryError(f"variable {v.get('rid', '?')} missing fields {missing}")
        if v["rid"] in seen:
            raise RegistryError(f"duplicate rid {v['rid']}")
        seen.add(v["rid"])
        if v["pillar"] not in ("I", "II", "III", "IV", "V"):
            raise RegistryError(f"variable {v['rid']} has unknown pillar {v['pillar']!r}")
        tier = v.get("tier")
        if tier is not None and tier not in ("A", "C", "H"):
            raise RegistryError(f"variable {v['rid']} has unknown tier {tier!r}")


@lru_cache(maxsize=1)
def load_registry(path: str | None = None) -> dict:
    """Load, validate and cache the registry. Refuses to return an invalid
    registry rather than let the engine run against bad data."""
    path = path or os.environ.get("DISS_REGISTRY_PATH") or _DEFAULT_PATH
    with open(path, "r", encoding="utf-8") as f:
        registry = json.load(f)
    _validate(registry)
    return registry


def variables(path: str | None = None) -> list[dict]:
    return load_registry(path)["vars"]


def variables_by_rid(path: str | None = None) -> dict[str, dict]:
    return {v["rid"]: v for v in variables(path)}


def registry_version(path: str | None = None) -> str:
    return load_registry(path).get("registry_version", "unknown")


def registry_sha256(path: str | None = None) -> str:
    return load_registry(path).get("registry_sha256", "unknown")


def public_variable(v: dict) -> dict:
    """Strip a variable record down to what a data-entry UI or an external
    API consumer may see. Never includes weight, scoring config, info-gain,
    criticality tier, or the exact flag-trigger condition."""
    return {k: val for k, val in v.items() if k not in _INTERNAL_ONLY_FIELDS}


def public_variables(path: str | None = None) -> list[dict]:
    return [public_variable(v) for v in variables(path)]


def registry_summary(path: str | None = None) -> dict:
    """Aggregate counts only — safe for an unauthenticated /api/diss/registry
    response. Never returns the variable list itself."""
    reg = load_registry(path)
    vs = reg["vars"]
    per_pillar = {}
    for p in reg["pillar_order"]:
        per_pillar[p] = sum(1 for v in vs if v["pillar"] == p)
    return {
        "registry_version": reg.get("registry_version"),
        "pillar_order": reg["pillar_order"],
        "pillar_names": reg["pillar_names"],
        "variable_count": len(vs),
        "variables_per_pillar": per_pillar,
    }
