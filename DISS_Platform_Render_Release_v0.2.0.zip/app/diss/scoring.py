"""The six locked scoring functions (SF-*), ported 1:1 from the live
DISS_Readiness_Calculator_v2.1 engine (`scoreOf`). Every branch below
matches the original JavaScript exactly, including its edge-case handling
(division-by-zero guards, hard-limit clamping). Do not "clean up" the
arithmetic without re-deriving it against the original and re-running
tests/test_scoring_parity.py.

A variable's `sc` (scoring config) dict carries a `"t"` type tag and the
type-specific parameters:

  high  {T, L}            -- higher is better; T=target (100), L=lower bound.
  low   {good, bad}        -- lower is better; good=100, bad=0.
  win   {lo, hi, loHard, hiHard} -- a healthy window [lo,hi]=100, decaying
                                    linearly out to the hard limits.
  pos   {T, base?}         -- positive-count scoring (e.g. AFC); base
                              defaults to 60, ramps to 100 at T.
  cat   {map}              -- categorical value -> fixed score lookup.
  bin   {yes, no}          -- "Yes"/"No" -> fixed scores.
"""


def score_of(sc, val):
    """Score one variable's value against its scoring config.

    Returns a float in [0, 100], or None if the value is missing/not
    scoreable (mirrors the original's `null` return, which the caller uses
    to exclude the variable from that pillar's aggregate).
    """
    if val is None or val == "" or sc is None:
        return None
    t = sc.get("t")

    if t == "high":
        try:
            x = float(val)
        except (TypeError, ValueError):
            return None
        T, L = sc["T"], sc["L"]
        if x >= T:
            return 100.0
        if x >= L:
            return 60 + 40 * (x - L) / (T - L)
        return max(0.0, 60 * x / (L or 1))

    if t == "low":
        try:
            x = float(val)
        except (TypeError, ValueError):
            return None
        good, bad = sc["good"], sc["bad"]
        if x <= good:
            return 100.0
        if x >= bad:
            return 0.0
        return 100 * (bad - x) / (bad - good)

    if t == "win":
        try:
            x = float(val)
        except (TypeError, ValueError):
            return None
        lo, hi, lo_hard, hi_hard = sc["lo"], sc["hi"], sc["loHard"], sc["hiHard"]
        if lo <= x <= hi:
            return 100.0
        if x < lo:
            return max(0.0, 100 * (x - lo_hard) / (lo - lo_hard))
        return max(0.0, 100 * (hi_hard - x) / (hi_hard - hi))

    if t == "pos":
        try:
            x = float(val)
        except (TypeError, ValueError):
            return None
        T = sc["T"]
        base = 60 if sc.get("base") is None else sc["base"]
        return min(100.0, base + (100 - base) * min(1.0, x / T))

    if t == "cat":
        m = sc.get("map") or {}
        return m.get(val)

    if t == "bin":
        if val == "Yes":
            return sc.get("yes")
        if val == "No":
            return sc.get("no")
        return None

    return None
