"""DISS™ Readiness Engine (Engine A) — stdlib-only clinical core.

Ported, function-for-function, from the locked and internally-verified
scoring/gating logic in DISS_Readiness_Calculator_v2.1 (the same engine used
to build every DISS demo report). This package has NO import of fastapi,
sqlalchemy or any web framework — it is deliberately import-clean so the
clinical core stays auditable and re-hostable on its own.

Modules:
    policy    — every governed constant in one place (bands, weakest-link
                floor, pillar order/names). Change clinical policy only here.
    scoring   — the six locked scoring functions (win/high/low/pos/cat/bin).
    registry  — loads and validates app/data/registry.json (692 variables);
                exposes a public-safe view that never leaks weight, scoring
                parameters, criticality tier or flag-trigger values.
    engine    — pillar aggregation, the three-tier criticality gate,
                overall verdict, data confidence, projected score.
    report    — turns an engine result into a patient-tier or clinician-tier
                report (Finding -> Interpretation -> Recommendation).
"""
