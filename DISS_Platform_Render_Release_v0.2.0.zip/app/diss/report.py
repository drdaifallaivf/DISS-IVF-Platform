"""Turns one Engine A result into a patient-tier or clinician-tier report.

Two tiers, per the locked product decision:
  patient   — plain language: what we found / what matters / what to do next.
  clinician — the same result plus RID-tagged Finding -> Interpretation ->
              Recommendation rows for every active flag ("Why?"), the
              criticality gate name, data confidence, and the projected
              score with its honesty label.

Neither tier exposes registry internals (weights, scoring parameters, exact
flag-trigger thresholds) — those stay server-side, in app/diss/registry.py's
_INTERNAL_ONLY_FIELDS. A report only ever carries clinical OUTPUT: the
finding, its plain-language interpretation, and the recommendation — which
is the actual deliverable a clinician or patient is meant to see.
"""
from __future__ import annotations

from . import policy

_TIER_LABEL = {
    "A": "Absolute — stops readiness regardless of score",
    "C": "Conditional — resolve before proceeding",
    "H": "Optimization recommended",
}


def _split_flagtext(text: str | None) -> tuple[str, str]:
    """flagtext is authored as 'finding — recommendation'. Split it once on
    an em/en dash; fall back to the whole string as the finding."""
    if not text:
        return "", ""
    for dash in ("—", " - "):
        if dash in text:
            finding, _, rec = text.partition(dash)
            return finding.strip(), rec.strip()
    return text.strip(), ""


def _flag_rows(flags: dict) -> list[dict]:
    rows = []
    for tier in policy.TIERS:
        for f in flags.get(tier, []):
            finding, rec = _split_flagtext(f.get("flagtext"))
            rows.append(
                {
                    "rid": f["rid"],
                    "variable": f["name"],
                    "pillar": f["pillar"],
                    "pillar_name": policy.PILLAR_NAMES.get(f["pillar"]),
                    "tier": tier,
                    "tier_label": _TIER_LABEL[tier],
                    "finding": finding or f.get("flagtext") or "",
                    "interpretation": f"{_TIER_LABEL[tier]} for {policy.PILLAR_NAMES.get(f['pillar'], f['pillar'])}.",
                    "recommendation": rec or "Clinician review required.",
                }
            )
    return rows


def clinician_report(result: dict) -> dict:
    per_pillar = [
        {
            "pillar": p,
            "pillar_name": policy.PILLAR_NAMES[p],
            "status": result["pillar_status"][p],
            "score": (result["per_pillar"].get(p) or {}).get("score"),
            "n_variables_scored": (result["per_pillar"].get(p) or {}).get("n"),
        }
        for p in policy.PILLAR_ORDER
    ]
    return {
        "tier": "clinician",
        "registry_version": result["registry_version"],
        "overall_score": result["overall_score"],
        "readiness": result["readiness"],
        "criticality_gate": {
            "active": bool(result["flags"]["A"] or result["flags"]["C"] or result["flags"]["H"]),
            "note": "Score never overrides an active criticality flag (Invariant I-5).",
        },
        "per_pillar": per_pillar,
        "why": _flag_rows(result["flags"]),
        "data_confidence": result["data_confidence"],
        "projected": result["projected"],
        "disclaimer": "Clinician-in-the-loop decision support · provisional weights · not for autonomous clinical use.",
    }


def patient_report(result: dict) -> dict:
    per_pillar = []
    for p in policy.PILLAR_ORDER:
        pv = result["per_pillar"].get(p)
        status = result["pillar_status"][p]
        per_pillar.append(
            {
                "pillar_name": policy.PILLAR_NAMES[p],
                "status": "Not assessed" if status == "NOT_ASSESSED" else status,
                "not_assessed": status == "NOT_ASSESSED",
            }
        )
    # Plain-language next steps: recommendation half of every active flag,
    # most severe tier first, de-duplicated.
    next_steps, seen = [], set()
    for row in _flag_rows(result["flags"]):
        if row["recommendation"] and row["recommendation"] not in seen:
            next_steps.append(row["recommendation"])
            seen.add(row["recommendation"])
    return {
        "tier": "patient",
        "readiness_level": result["readiness"]["level"],
        "summary": result["readiness"]["sub"],
        "pillars": per_pillar,
        "what_to_do_next": next_steps,
        "disclaimer": "This is a simplified summary to help you understand your readiness and discuss it with your care team. Not a medical decision on its own.",
    }


def build(result: dict, tier: str = "both") -> dict:
    if tier == "patient":
        return patient_report(result)
    if tier == "clinician":
        return clinician_report(result)
    return {"patient": patient_report(result), "clinician": clinician_report(result)}
