from datetime import date
from decimal import Decimal
from sqlalchemy import select
from .database import Base, engine, SessionLocal
from .models import *

Base.metadata.create_all(bind=engine)

def run():
    db=SessionLocal()
    try:
        if db.scalar(select(Patient).limit(1)):
            print("Seed skipped: data already exists"); return
        s=Supplier(name="IVF Lab Supplies Co.", contact_email="sales@example.com")
        db.add(s); db.flush()
        p=Patient(mrn="DISS-0001", full_name="Demo Patient", dob=date(1991,5,12), sex="female", center="Demo IVF Center")
        db.add(p); db.flush()
        db.add_all([
            ClinicalDatum(patient_id=p.id, category="history", name="medical_history", value_text="Demo verified history", verified=True),
            ClinicalDatum(patient_id=p.id, category="history", name="reproductive_history", value_text="Demo reproductive history", verified=True),
            ClinicalDatum(patient_id=p.id, category="lab", name="amh", value_num=2.4, unit="ng/mL", verified=True),
            ClinicalDatum(patient_id=p.id, category="imaging", name="afc", value_num=12, verified=True),
        ])
        c=IVFcycle(patient_id=p.id, cycle_code="CYCLE-0001", phase="assessment")
        db.add(c)
        db.add_all([
            DISSInput(patient_id=p.id, rid="DISS-P1-D01-C03-V025", value="33", verified=True),
            DISSInput(patient_id=p.id, rid="DISS-P1-D01-C03-V026", value="36", verified=True),
            DISSInput(patient_id=p.id, rid="DISS-P1-D01-C01-V003", value="24.1", verified=True),
            DISSInput(patient_id=p.id, rid="DISS-P2-D01-C01-V003", value="Yes", verified=True),
            DISSInput(patient_id=p.id, rid="DISS-P2-D01-C02-V005", value="9.5", verified=True),
            DISSInput(patient_id=p.id, rid="DISS-P3-D01-C03-V011", value="42", verified=True),
            DISSInput(patient_id=p.id, rid="DISS-P3-D01-C04-V015", value="38", verified=True),
        ])
        db.add_all([
            InventoryItem(sku="MED-001", name="Embryo culture medium", category="Culture Media", center="Demo IVF Center", department="Embryology", qty_on_hand=4, reorder_level=10, unit_cost=Decimal("250"), supplier_id=s.id),
            MarketplaceProduct(supplier_id=s.id, sku="MED-001", name="Embryo culture medium", category="Culture Media", description="Demo marketplace listing", price=Decimal("310"), sponsored=True),
            CommercialPlacement(title="Demo supplier campaign", body="Sponsored commercial content is separated from clinical recommendations.", sponsor="IVF Lab Supplies Co.", active=True),
            PatientLedger(patient_id=p.id, entry_type="charge", category="IVF", description="IVF package", amount=Decimal("12000")),
            PatientLedger(patient_id=p.id, entry_type="payment", category="Payment", description="Deposit", amount=Decimal("5000")),
        ])
        db.commit(); print("Seed complete")
    finally:
        db.close()

if __name__ == "__main__": run()
