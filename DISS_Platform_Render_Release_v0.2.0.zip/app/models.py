from __future__ import annotations
from datetime import datetime, date
from decimal import Decimal
from sqlalchemy import String, Integer, DateTime, Date, ForeignKey, Numeric, Text, Boolean, Float
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base

class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Patient(Base, TimestampMixin):
    __tablename__ = "patients"
    id: Mapped[int] = mapped_column(primary_key=True)
    mrn: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(200))
    dob: Mapped[date | None] = mapped_column(Date, nullable=True)
    sex: Mapped[str | None] = mapped_column(String(20), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    email: Mapped[str | None] = mapped_column(String(200), nullable=True)
    center: Mapped[str | None] = mapped_column(String(120), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="active")

class ClinicalDatum(Base, TimestampMixin):
    __tablename__ = "clinical_data"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), index=True)
    category: Mapped[str] = mapped_column(String(60), index=True) # lab, imaging, history, genetics, surgery, embryology
    name: Mapped[str] = mapped_column(String(160))
    value_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    value_num: Mapped[float | None] = mapped_column(Float, nullable=True)
    unit: Mapped[str | None] = mapped_column(String(40), nullable=True)
    source: Mapped[str | None] = mapped_column(String(200), nullable=True)
    verified: Mapped[bool] = mapped_column(Boolean, default=False)
    observed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

class IVFcycle(Base, TimestampMixin):
    __tablename__ = "ivf_cycles"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), index=True)
    cycle_code: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    phase: Mapped[str] = mapped_column(String(40), default="assessment")
    protocol_name: Mapped[str | None] = mapped_column(String(120), nullable=True)
    trigger_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    opu_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    transfer_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    outcome: Mapped[str | None] = mapped_column(String(80), nullable=True)

class EmbryologyRecord(Base, TimestampMixin):
    __tablename__ = "embryology_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), index=True)
    cycle_id: Mapped[int] = mapped_column(ForeignKey("ivf_cycles.id"), index=True)
    specimen_code: Mapped[str] = mapped_column(String(80), index=True)
    record_type: Mapped[str] = mapped_column(String(40)) # oocyte, sperm, embryo
    stage: Mapped[str | None] = mapped_column(String(80), nullable=True)
    grade: Mapped[str | None] = mapped_column(String(80), nullable=True)
    image_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    storage_location: Mapped[str | None] = mapped_column(String(120), nullable=True)
    disposition: Mapped[str | None] = mapped_column(String(80), nullable=True)

class ClinicalRecommendation(Base, TimestampMixin):
    __tablename__ = "clinical_recommendations"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), index=True)
    cycle_id: Mapped[int | None] = mapped_column(ForeignKey("ivf_cycles.id"), nullable=True)
    state: Mapped[str] = mapped_column(String(40))
    title: Mapped[str] = mapped_column(String(180))
    rationale: Mapped[str] = mapped_column(Text)
    evidence_ref: Mapped[str | None] = mapped_column(String(300), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="pending")
    physician_comment: Mapped[str | None] = mapped_column(Text, nullable=True)

class Medication(Base, TimestampMixin):
    __tablename__ = "medications"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), index=True)
    cycle_id: Mapped[int | None] = mapped_column(ForeignKey("ivf_cycles.id"), nullable=True)
    drug_name: Mapped[str] = mapped_column(String(160))
    dose: Mapped[str | None] = mapped_column(String(120), nullable=True)
    schedule: Mapped[str | None] = mapped_column(String(120), nullable=True)
    prescriber: Mapped[str | None] = mapped_column(String(160), nullable=True)
    status: Mapped[str] = mapped_column(String(40), default="proposed")

class PatientLedger(Base, TimestampMixin):
    __tablename__ = "patient_ledger"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), index=True)
    entry_type: Mapped[str] = mapped_column(String(30)) # charge, payment, refund, discount
    category: Mapped[str] = mapped_column(String(80))
    description: Mapped[str] = mapped_column(String(240))
    amount: Mapped[Decimal] = mapped_column(Numeric(12,2))
    currency: Mapped[str] = mapped_column(String(10), default="SAR")
    cycle_id: Mapped[int | None] = mapped_column(ForeignKey("ivf_cycles.id"), nullable=True)

class CostCenter(Base, TimestampMixin):
    __tablename__ = "cost_centers"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(140), unique=True)
    center_name: Mapped[str | None] = mapped_column(String(140), nullable=True)
    kind: Mapped[str] = mapped_column(String(30), default="cost_center")

class Supplier(Base, TimestampMixin):
    __tablename__ = "suppliers"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(180), unique=True)
    contact_email: Mapped[str | None] = mapped_column(String(180), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(80), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class InventoryItem(Base, TimestampMixin):
    __tablename__ = "inventory_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    sku: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180))
    category: Mapped[str] = mapped_column(String(100))
    center: Mapped[str] = mapped_column(String(120))
    department: Mapped[str] = mapped_column(String(120))
    qty_on_hand: Mapped[float] = mapped_column(Float, default=0)
    reorder_level: Mapped[float] = mapped_column(Float, default=0)
    unit_cost: Mapped[Decimal] = mapped_column(Numeric(12,2), default=0)
    supplier_id: Mapped[int | None] = mapped_column(ForeignKey("suppliers.id"), nullable=True)
    lot_number: Mapped[str | None] = mapped_column(String(100), nullable=True)
    expiry_date: Mapped[date | None] = mapped_column(Date, nullable=True)

class PurchaseOrder(Base, TimestampMixin):
    __tablename__ = "purchase_orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    supplier_id: Mapped[int] = mapped_column(ForeignKey("suppliers.id"))
    center: Mapped[str] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(40), default="draft")
    total_amount: Mapped[Decimal] = mapped_column(Numeric(12,2), default=0)
    currency: Mapped[str] = mapped_column(String(10), default="SAR")

class MarketplaceProduct(Base, TimestampMixin):
    __tablename__ = "marketplace_products"
    id: Mapped[int] = mapped_column(primary_key=True)
    supplier_id: Mapped[int] = mapped_column(ForeignKey("suppliers.id"))
    sku: Mapped[str] = mapped_column(String(80), index=True)
    name: Mapped[str] = mapped_column(String(180))
    category: Mapped[str] = mapped_column(String(100))
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    price: Mapped[Decimal | None] = mapped_column(Numeric(12,2), nullable=True)
    currency: Mapped[str] = mapped_column(String(10), default="SAR")
    sponsored: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class DISSInput(Base, TimestampMixin):
    """One captured value for one DISS registry variable (by RID), for one
    patient. Upserted by RID — the current row is the patient's latest
    known value for that variable, with its source and verification status
    (mirrors the existing ClinicalDatum discipline: unverified/free-text
    values are still visible but never silently promoted to 'confirmed')."""
    __tablename__ = "diss_inputs"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), index=True)
    rid: Mapped[str] = mapped_column(String(60), index=True)
    value: Mapped[str] = mapped_column(String(500))
    source: Mapped[str | None] = mapped_column(String(200), nullable=True)
    verified: Mapped[bool] = mapped_column(Boolean, default=False)


class DISSAssessment(Base, TimestampMixin):
    """A stored, immutable Engine A run. GET /api/diss/assessments/{id}
    REPLAYS this row rather than recomputing — what a clinician was shown
    is a matter of record, even if the registry is updated afterwards."""
    __tablename__ = "diss_assessments"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), index=True)
    registry_version: Mapped[str] = mapped_column(String(80))
    tier: Mapped[str] = mapped_column(String(20), default="both")
    inputs_json: Mapped[str] = mapped_column(Text)
    result_json: Mapped[str] = mapped_column(Text)
    report_json: Mapped[str] = mapped_column(Text)


class CommercialPlacement(Base, TimestampMixin):
    __tablename__ = "commercial_placements"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(180))
    body: Mapped[str] = mapped_column(Text)
    sponsor: Mapped[str] = mapped_column(String(180))
    placement: Mapped[str] = mapped_column(String(80), default="marketplace_footer")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
