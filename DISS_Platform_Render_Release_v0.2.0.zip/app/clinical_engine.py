"""The DB <-> clinical-core boundary. This is the ONLY module in the app
that is allowed to import both SQLAlchemy and app.diss — every other module
either talks to the database (app/main.py, app/models.py) or talks to the
clinical core (app/diss/*), never both.

Replaces the v0.1 placeholder completeness-check with the real DISS
Readiness Engine (Engine A), wired to per-patient DISSInput rows keyed by
registry RID. An assessment is computed from the patient's CURRENT inputs,
then stored immutably in DISSAssessment — a later read of that assessment
replays the stored result, it never recomputes against a since-changed
registry or since-edited inputs (matters if a value is corrected after a
clinician has already acted on a report).
"""
from __future__ import annotations

import json

from sqlalchemy import select
from sqlalchemy.orm import Session

from .diss import engine as diss_engine
from .diss import registry as diss_registry
from .diss import report as diss_report
from .models import ClinicalRecommendation, DISSAssessment, DISSInput

_TIER_TO_RECOMMENDATION_TITLE = {
    "Not Ready — STOP": "Absolute red flag — do not proceed",
    "Not Ready": "Resolve STOP-level pillar before proceeding",
    "Partially Ready — conditional": "Resolve conditional flag before proceeding",
    "Partially Ready": "Investigate REVIEW-level pillar(s)",
    "Nearly Ready — optimise": "Optimise HOLD-level factor(s) before transfer",
    "Ready": "Clinical review to confirm readiness",
    "Unassessed": "Complete baseline DISS assessment",
}


def upsert_inputs(db: Session, patient_id: int, inputs: list[dict]) -> list[DISSInput]:
    """Upsert {rid, value, source, verified} rows for a patient. One row per
    RID — a later upsert of the same RID replaces the earlier value."""
    out = []
    for item in inputs:
        row = db.scalar(
            select(DISSInput).where(DISSInput.patient_id == patient_id, DISSInput.rid == item["rid"])
        )
        if row is None:
            row = DISSInput(patient_id=patient_id, rid=item["rid"], value=item["value"])
            db.add(row)
        else:
            row.value = item["value"]
        row.source = item.get("source")
        row.verified = bool(item.get("verified", False))
        out.append(row)
    db.commit()
    for row in out:
        db.refresh(row)
    return out


def current_values(db: Session, patient_id: int) -> dict:
    rows = db.scalars(select(DISSInput).where(DISSInput.patient_id == patient_id)).all()
    return {r.rid: r.value for r in rows}


def run_assessment(db: Session, patient_id: int, tier: str = "both") -> DISSAssessment:
    """Compute Engine A over the patient's current inputs, build the
    requested report tier(s), and store the run immutably."""
    values = current_values(db, patient_id)
    result = diss_engine.assess(values)
    report = diss_report.build(result, tier=tier)

    row = DISSAssessment(
        patient_id=patient_id,
        registry_version=result["registry_version"],
        tier=tier,
        inputs_json=json.dumps(values, ensure_ascii=False),
        result_json=json.dumps(result, ensure_ascii=False),
        report_json=json.dumps(report, ensure_ascii=False),
    )
    db.add(row)
    db.commit()
    db.refresh(row)

    # Every active flag becomes a pending ClinicalRecommendation in the
    # existing approve/modify/reject workflow, RID-tagged for traceability.
    flags = result["flags"]
    if flags["A"] or flags["C"] or flags["H"]:
        title = _TIER_TO_RECOMMENDATION_TITLE.get(result["readiness"]["level"], "Clinical review required")
        rationale_lines = []
        for t in ("A", "C", "H"):
            for f in flags[t]:
                rationale_lines.append(f"[{t}] {f['rid']} {f['name']}: {f.get('flagtext') or ''}")
        rec = ClinicalRecommendation(
            patient_id=patient_id,
            state=result["readiness"]["level"],
            title=title,
            rationale="\n".join(rationale_lines) or "See DISS assessment for detail.",
            evidence_ref=f"DISS assessment #{row.id} · registry {row.registry_version}",
        )
        db.add(rec)
        db.commit()

    return row


def replay_assessment(db: Session, assessment_id: int) -> DISSAssessment | None:
    """Read back a stored assessment as-shown — never recomputes."""
    return db.get(DISSAssessment, assessment_id)


def list_assessments(db: Session, patient_id: int) -> list[DISSAssessment]:
    return list(
        db.scalars(
            select(DISSAssessment)
            .where(DISSAssessment.patient_id == patient_id)
            .order_by(DISSAssessment.created_at.desc())
        ).all()
    )


def registry_summary() -> dict:
    return diss_registry.registry_summary()


def public_variables() -> list[dict]:
    return diss_registry.public_variables()
